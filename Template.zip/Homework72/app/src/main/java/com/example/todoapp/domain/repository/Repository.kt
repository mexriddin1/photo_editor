package com.example.todoapp.domain.repository

interface Repository {

}