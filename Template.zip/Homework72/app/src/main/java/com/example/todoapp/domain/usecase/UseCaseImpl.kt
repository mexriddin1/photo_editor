package com.example.todoapp.domain.usecase

import javax.inject.Inject

class UseCaseImpl @Inject constructor() : UseCase {

}