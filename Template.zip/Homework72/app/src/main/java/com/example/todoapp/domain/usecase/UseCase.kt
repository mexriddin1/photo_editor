package com.example.todoapp.domain.usecase

interface UseCase {
}