package com.example.todoapp.domain.repository

import javax.inject.Inject

class RepositoryImpl @Inject constructor(

) : Repository {

}