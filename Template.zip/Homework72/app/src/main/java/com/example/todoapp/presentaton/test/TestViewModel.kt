package com.example.todoapp.presentaton.test

import androidx.lifecycle.ViewModel
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject

@HiltViewModel
class TestViewModel @Inject constructor(
    private val direction: TestContract.Direction
) : ViewModel(), TestContract.ViewModel {

    override val container = container<TestContract.UiState, Any>(TestContract.UiState())

    override fun onEventDispatcher(intent: TestContract.Intent) = intent {
        when (intent) {
            else -> {

            }
        }
    }
}
