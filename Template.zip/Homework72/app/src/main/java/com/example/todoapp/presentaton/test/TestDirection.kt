package com.example.todoapp.presentaton.test

import javax.inject.Inject

class TestDirection @Inject constructor(
    private val appNavigator: AppNavigator
) : TestContract.Direction {

}
