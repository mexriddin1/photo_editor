package com.example.todoapp.presentaton.test

import androidx.compose.runtime.Composable
import androidx.compose.ui.tooling.preview.Preview
import cafe.adriel.voyager.core.screen.Screen
import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import cafe.adriel.voyager.hilt.getViewModel
import org.orbitmvi.orbit.compose.collectAsState

class TestScreen : Screen {
    @Composable
    override fun Content() {
        val viewModel: TestContract.ViewModel =
            getViewModel<TestViewModel>()
        val uiState = viewModel.collectAsState()
        TestScreenContent(uiState, viewModel::onEventDispatcher)
    }
}

@Composable
fun TestScreenContent(
    uiState: State<TestContract.UiState> = remember {
        mutableStateOf(
            TestContract.UiState()
        )
    }, onEventDispatcher: (intent: TestContract.Intent) -> Unit = {}
) {

}

@Preview
@Composable
fun TestScreenPreview() {
    TestScreenContent()
}