package com.example.todoapp.utils.navigation

import cafe.adriel.voyager.core.screen.Screen
import cafe.adriel.voyager.navigator.Navigator


typealias NavigatorArgs = Navigator.() -> Unit
typealias AppScreen = Screen

